# NexusCRM — Real Estate CRM Dashboard

A comprehensive, single-file CRM dashboard built for real estate management. No dependencies, no build tools — just open the HTML file in any browser.

## Features

- **8 Modules** — Contacts, Companies, Deals, Tasks, Projects, Inventory, Negotiations, Bookings
- **Dashboard Analytics** — Live KPI cards, deal stage chart, revenue chart (all from real data)
- **Login System** — User authentication, session persistence, owner auto-population
- **Add Fields System** — Each create modal has a top-right "Add Fields" dropdown to optionally add extra fields per module
- **Advanced Filters** — Per-module filter panel with field-aware conditions (text, status, date, number, owner)
- **Grid & List Views** — Toggle between table and card views in every module
- **Bookmarks** — Save any record for quick access
- **Import / Export** — File picker modal per module
- **Org Selector** — Switch between 15 Indian cities in the topbar
- **Fullscreen Charts** — 7 chart types (Column, Bar, Line, Area, Pie, Donut, Table)
- **Responsive Sidebar** — Collapsible with icon-only mode

## Modules

| Module | Description |
|---|---|
| Contacts | Manage leads and clients with Aadhar, PAN, photo upload support |
| Companies | Track organizations with GSTIN, PAN, logo upload |
| Deals | Pipeline management with stage tracking and revenue charts |
| Tasks | Activity tracking with reminders and priority levels |
| Projects | Real estate project management with RERA, amenities |
| Inventory | Unit-level tracking with BHK, floor, facing details |
| Negotiations | Price negotiation workflow with approval chain |
| Bookings | Booking management with payment tracking |

## Tech Stack

- **Vanilla HTML / CSS / JavaScript** — zero dependencies
- **localStorage** — all data persisted in the browser
- **Single file** — entire app is `src/NexusCRM_Dashboard.html`
- **Fonts** — DM Sans + Fraunces (loaded from Google Fonts)

## Getting Started

1. Download `src/NexusCRM_Dashboard.html`
2. Open it in any modern browser
3. Create your account on the login screen
4. Start adding data — the dashboard updates live

## Screenshots

> Dashboard with live KPI cards, deal stage chart and revenue chart

## Project Structure

```
NexusCRM/
├── src/
│   └── NexusCRM_Dashboard.html   ← The entire app
├── docs/
│   └── FEATURES.md               ← Detailed feature documentation
├── assets/
│   └── (screenshots can go here)
└── README.md
```

## License

MIT — free to use and modify.
